import { Component,OnInit } from "@angular/core";
import { NgForm } from "@angular/forms";
import { Subscription } from "rxjs";

@Component({
  selector: 'app-buswizard',
  templateUrl: './buswizard.component.html',
  styleUrls: ['./buswizard.component.scss']
})
export class BuswizardComponent implements OnInit {
  
  
  constructor() { 
  }
  ngOnInit(): void {
   
    
  } 

}