import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mastersetting',
  templateUrl: './mastersetting.component.html',
  styleUrls: ['./mastersetting.component.scss']
})
export class MastersettingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
