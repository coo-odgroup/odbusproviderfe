import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seosetting',
  templateUrl: './seosetting.component.html',
  styleUrls: ['./seosetting.component.scss']
})
export class SeosettingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
