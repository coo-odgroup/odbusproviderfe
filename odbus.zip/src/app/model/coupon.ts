export interface Coupon {
    id:any;
    coupon_title:any;
    short_desc:any;
    full_desc:any;
    type:any;
    percentage:any;
    max_discount:any;
    cut_off_amount:any;
    min_tran_amount:any;
    valid_by:any;
    from_date:any;
    to_date:any;
    max_redeem:any;
    coupon_code:any;
}
