export interface Cancellationslab {
    id:string;
    api_id:any;
    rule_name:any;
    duration:any;
    deduction:any;
    status:1;
    api_name:any;
    slab_info:any;
    cancellation_policy_desc:any;
}
