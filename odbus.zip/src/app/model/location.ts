export interface Location {
        id: any;
        name: any;
        synonym: any;
        created_at: any;
        updated_at: any;
        created_by: any;
        status: any;

 
 }

 export interface LocationCode {
         id: any;
         location_id: any;
         type: any;
         providerid: any;
         created_at: any;
         updated_at: any;
         created_by: any;
         status: any;


 }