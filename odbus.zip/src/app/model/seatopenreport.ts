export interface SeatOpenReport {   
    bus_operator_id: any; 
    bus_id: any;   
    // date_range: any;
    rows_number: any;
    rangeFromDate:any;
    rangeToDate:any;

}
