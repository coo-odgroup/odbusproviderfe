export interface OwnerpaymentReport {   
    bus_operator_id: any;   
    date_range: any;   
    rows_number: any;
    rangeFromDate: any;
    rangeToDate : any;
}
