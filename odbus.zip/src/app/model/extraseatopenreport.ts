export interface ExtraSeatOpenReportReport {   
    bus_operator_id: any;   
    rows_number: any ;
   
}
