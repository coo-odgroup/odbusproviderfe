export interface Safety {
     id: number;
     name: string;
     icon:any;
     iconSrc:any;
     created_at: string;
     updated_at: string;
     created_by: string;
     status: 1;
 
 }
 