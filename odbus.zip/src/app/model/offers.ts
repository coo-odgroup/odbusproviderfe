export interface Offers {
    offer_category_id:Number;
    offer_image:any;
    offer_text:any;
    status:Number;
    id:Number;
    created_by:any;
    created_at:any;
    updated_at:any;
}
