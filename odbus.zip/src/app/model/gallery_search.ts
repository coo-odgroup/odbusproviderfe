export interface GallerySearch {
    bus_id: any;
    rows_number:any;
}
