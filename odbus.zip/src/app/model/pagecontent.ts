export interface Pagecontent {
    id:any ;
    page_name:any;
    page_url:any;
    page_description:any;
    meta_title:any;
    meta_keyword:any;
    meta_description:any;
    extra_meta:any;
    canonical_url:any;
}
