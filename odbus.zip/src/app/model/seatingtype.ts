export interface Seatingtype {
     id: any;
     name: any;
     created_at: any;
     updated_at: any;
     created_by: any;
     status: 1;
 
 }
 