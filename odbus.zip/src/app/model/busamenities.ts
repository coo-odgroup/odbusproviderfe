export interface Busamenities {
    id:any;
    bus_id:any;
    amenities_id:any;
    created_at:any;
    created_by:any;
    status:any;
}
