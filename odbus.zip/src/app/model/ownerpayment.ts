export interface Ownerpayment {
    amount: any;
    transaction_id:any;
    bus_operator_id: any ;
    date: any;
    remark: any;
}
