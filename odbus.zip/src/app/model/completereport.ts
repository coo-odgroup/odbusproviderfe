export interface CompleteReport {   
    bus_operator_id: any;   
    payment_id: any;
    date_type: any;
    rows_number: any;
    source_id:any ;
    destination_id:any ;
    rangeFromDate:any;
    rangeToDate:any;

}
