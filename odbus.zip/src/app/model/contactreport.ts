export interface Contactreport {
    id :any;
    name : any;
    email : any;
    phone : any;
    service : any;
    message : any;
}
