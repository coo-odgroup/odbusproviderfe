export interface Busschedule {
    id: any;
    bus_id: any;
    bus_operator_id: any;
    running_cycle: any;
    entry_date: any;
    created_by: 'admin';
    status: 0; 
    entryDates: [];
}
