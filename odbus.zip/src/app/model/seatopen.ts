export interface Seatopen{
    bus_seat_layout_data: any;
    selectedSeat: any;
    searchBy: any;
    id: any;
    bus_operator_id: any;    
    bus_id: any;
    date: any;
    reason: any;
    created_at: any;
    updated_at: any;
    created_by:'Admin',
    status: 1;
    name: any;
    date_applied:any;
    seat_open_seats:any;
    bus:any;

}
