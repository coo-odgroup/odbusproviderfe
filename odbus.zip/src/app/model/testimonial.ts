export interface Testimonial{
    id:any;
    posted_by: any;
    testinmonial_content: any;
    location: any;
    designation: any; 

}
