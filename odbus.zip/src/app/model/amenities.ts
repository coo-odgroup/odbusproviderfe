export interface Amenities {
    id:number;
    name:string;
    icon:any;
    created_at:string;
    reason:any;
    updated_at:string;
    created_by:string;
    status:1;
    iconSrc:any;
}
