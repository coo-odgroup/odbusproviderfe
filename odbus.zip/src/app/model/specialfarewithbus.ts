
export interface SpecialfareWithBus {
    id: any;
    bus_id: any;
    special_fare_id: any;
    
}
