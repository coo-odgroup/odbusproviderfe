export interface SocialMedia{
    facebook_link: any;
    twitter_link: any;
    instagram_link: any;
    googleplus_link: any;
    linkedin_link: any;
}
