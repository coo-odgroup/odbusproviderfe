export interface BusCancellationReport {   
    bus_operator_id: any; 
    bus_id: any;   
    rows_number: any;
    rangeFromDate:any;
    rangeToDate:any;

}
