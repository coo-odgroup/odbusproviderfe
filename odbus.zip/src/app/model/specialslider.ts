export interface SpecialSlider {
    id:any;
    occassion:any;
    category:any;
    url:any;
    slider_img:any;
    alt_tag:any;
    start_date:any;
    start_time:any;
    end_date:any;
    end_time:any;
    iconSrc:any;
    created_by: string;
    status: 1;
}
