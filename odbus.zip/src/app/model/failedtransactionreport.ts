export interface FailedtransactionReport {   
    bus_operator_id: any;   
    rangeFromDate:any ;
    rangeToDate:any ;
    payment_id: any;
    date_type: any;
    rows_number: any;
    source_id:any;
    destination_id:any;
    
}
