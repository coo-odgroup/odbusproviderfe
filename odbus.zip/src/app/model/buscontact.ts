export interface Buscontact {
    bus_id: any;
    type: any;
    phone: any;
    booking_sms_send: any;
    cancel_sms_send: any,
    created_by:any;
    
}
