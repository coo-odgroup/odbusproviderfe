export interface Bus {
    id: any;
    bus_operator_id: any;
    location_id: any;
    user_id: any;
    name: any;
    via: any;
    bus_number: any;
    bus_description: any;
    bus_type_id: any;
    bus_sitting_id: any;
    cancellationslabs_id: any;
    cancelation_points: any;
    bus_seat_layout_id: any;
    running_cycle: any;
    popularity: any;
    admin_notes: any;
    amenities:any;
    safety:any;
    //has_return_bus: any;
    return_bus_id: any;
    created_at: any;
    updated_at: any;
    created_by: any;
    status:'1';
    busnamenumber:any;
    bus_amenities:any;
    max_seat_book:any;    
}
