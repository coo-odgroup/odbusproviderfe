export interface SettingsRecords{
    payment_gateway_charges?:any;
    email_sms_charges?:any;
    odbus_gst_charges?:any;
    advance_days_show?:any;
    support_email?:any;
    booking_email?:any;
    request_email?:any;
    other_email?:any;
    mobile_no_1?:any;
    mobile_no_2?:any;
    mobile_no_3?:any;
    mobile_no_4?:any;

  } 
  