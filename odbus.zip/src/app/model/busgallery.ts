export interface Busgallery {
    bus_id: any;
    id:number;
    name:string;
    icon:string;
    created_at:string;
    reason:any;
    updated_at:string;
    created_by:string;
    status:1;
    iconSrc:any;
}
