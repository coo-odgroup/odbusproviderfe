import { TestBed } from '@angular/core/testing';

import { BusTypeService } from './bus-type.service';

describe('SeatTypeServiceService', () => {
  let service: BusTypeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BusTypeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
