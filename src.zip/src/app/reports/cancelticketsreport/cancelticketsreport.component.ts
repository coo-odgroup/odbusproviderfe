import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cancelticketsreport',
  templateUrl: './cancelticketsreport.component.html',
  styleUrls: ['./cancelticketsreport.component.scss']
})
export class CancelticketsreportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
