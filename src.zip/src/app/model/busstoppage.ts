export interface Busstoppage {
    bus_id: any;
    user_id: any;
    source_id: any;
    destination_id: any;
    base_seat_fare: any;
    base_sleeper_fare: any;
    dep_time: any;
    arr_time: any;
    j_day: any;
    created_by: any;
    
}
