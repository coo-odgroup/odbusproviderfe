export interface BusSquence {
    id: any;
    bus_id: any;
    sequence: any;
}
