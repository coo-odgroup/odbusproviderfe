export interface Specialfare {
    searchBy: any;
    id: any;
    bus_operator_id: any;
    source_id: any;
    destination_id:any;
    bus_id: any;
    date: any;
    seater_price: any;
    sleeper_price: any;
    reason: any;
    created_at: any;
    updated_at: any;
    created_by:'Admin',
    status: 1;
    name: any;
}
