export interface SeatLayout {
    id: any;
    name: any;
    layout_data: any;
    created_at: any;
    created_by: any;
    status: any;
    layoutControl:sLayoutData
}
export interface sLayoutData {  
    sLayout: any[];   
  }
