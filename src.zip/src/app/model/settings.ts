export interface SettingsRecords{
    payment_gateway_charges?:any;
    email_sms_charges?:any;
    odbus_gst_charges?:any;
  } 
 