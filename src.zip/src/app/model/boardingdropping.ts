export interface BoardingDropping {
    id:any;
    location_id:any;
    location_name:any;
    //boarding_point: boarding_point[]= [];
    boarding_point:any;
    boarding_dropping:any;
    created_at:any;
    created_by:any;
    status:1;
}
