export interface Bustype {
  id: any;
  type: any;
  name: any;
  created_at: any;
  updated_at: any;
  created_by: any;
  status: 1;
  bus_class_id:any;
}
